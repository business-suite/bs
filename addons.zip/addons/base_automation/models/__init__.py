# -*- coding: utf-8 -*-


from . import base_automation
from . import ir_actions
