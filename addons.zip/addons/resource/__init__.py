# -*- coding: utf-8 -*-


from . import models
from .tests import test_resource_model
