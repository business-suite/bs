# -*- coding: utf-8 -*-


from . import test_res_config
from . import test_res_config_doc_links
