# -*- coding: utf-8 -*-


from . import res_company
from . import res_country
from . import res_partner
