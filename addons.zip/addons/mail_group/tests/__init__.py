# -*- coding: utf-8 -*-


from . import test_mail_group
from . import test_mail_group_message
from . import test_mail_group_moderation
