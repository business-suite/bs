# -*- coding: utf-8 -*-


from . import mail_group_message_reject
