# -*- coding: utf-8 -*-


from . import test_controller
from . import test_converter
from . import test_odoo_editor
from . import test_views
