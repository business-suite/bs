# -*- coding: utf-8 -*-


from . import test_message_format_portal
from . import test_tours
from . import test_portal_wizard
