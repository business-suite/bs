# -*- coding: utf-8 -*-


from . import ir_http
from . import ir_ui_view
from . import mail_thread
from . import mail_message
from . import portal_mixin
from . import res_config_settings
from . import res_partner
from . import res_users_apikeys_description
