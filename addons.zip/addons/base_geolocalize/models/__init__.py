# -*- coding: utf-8 -*-

from . import base_geocoder
from . import res_config_settings
from . import res_partner
